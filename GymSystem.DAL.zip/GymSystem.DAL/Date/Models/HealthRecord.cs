﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymSystem.DAL.Date.Models
{
    public class HealthRecord : BaseU
    {
        public decimal Height { get; set; }
        public decimal Weight { get; set; }
        public string? Note { get; set; }
        public string BloodType { get; set; }

        // Lastupdate == updaetdAt

        #region  Relationships
        public Member Member { get; set; }
        public int MemberId { get; set; }

        #endregion
    }
}
