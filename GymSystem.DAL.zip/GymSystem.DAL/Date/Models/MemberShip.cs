﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymSystem.DAL.Date.Models
{
    public class MemberShip : BaseU
    {
        public Member Member { get; set; }
        public int MemberId { get; set; }
        public Plan Plan { get; set; }
        public int PlanId { get; set; }

        // StartDate is createdat from the base 
        public DateTime? EndDate { get; set; }


        public string Status => EndDate > DateTime.Now ? "Active" : "Expired";
        public bool MyProperty { get; set; }
    }
}
